# lara-decrypt

基于 [lara](https://github.com/rooootdev/lara)(DarkSword 内核漏洞工具箱)裁剪出来的精简版本。
原版是个大杂烩(SpringBoard 定制、图标主题、字体覆盖、OTA、ScreenTime、RemoteCall 定制器……),
这一版**只留三件事**:

| 功能 | 位置 | 依赖 |
| - | - | - |
| 内核读写 + 初始化系统 | 第一个 tab(主页) | darksword exploit + VFS / SBX escape |
| App 解密(砸壳) | 第二个 tab | SBX escape(必须先初始化系统) |
| 文件管理器 | 第三个 tab | VFS / SBX |

界面就四个 tab:内核 · 解密 · 文件 · 日志(日志 tab 只在设置里把「Logs Display」调成 In Tabs 时出现)。

## 使用顺序

1. 主页点 **Run Exploit** → 等进度到 100%(状态变对勾)
2. 如果没 offset,点 **Fetch Kernelcache**(或设置里 Import Kernelcache)
3. 点 **Initialize System** → VFS + SBX 都变对勾
4. 切到 **解密** tab → 刷新列表 → 点要砸的 App(会自动拉起目标 App 再回来解密)
5. 解出来的 ipa 落在本 App 的 Documents 里,可以用系统「文件」App 取走

## 删掉了什么

**界面 / 功能层(整文件删除)**

- TweaksView(整个「工具」页)、RemoteView(RemoteCall 定制器)
- CardView、FontPicker、JitView、OTAView、ScreenTimeView、ShowHiddenIconsView、SystemColor
- VarCleanView + VarCleanBridge.m + VarCleanRules.json
- WhitelistView、AppsView、CustomView、ToolsView
- darkboard / dirtyZero / liquidglass / mobilegestalt / passcode / sbcustomizer / broken 全部子目录
- respringview(注销视图)、IconThemeManager 等图标主题管理器
- 主页的 **RemoteCall** 段、**Respring**、**Panic!** 三个入口
- 设置页的 RemoteCall(Stash KRW / Keep SpringBoard alive / >10 dock icons)与 iOS16 相关项

**底层**

- `kexploit/pe/rc.m` + `rc.h`(SpringBoard 远程定制那一大套)
- `kexploit/ota.m`、`kexploit/screentime.m` 及其头文件

**设置页保留了**:About / Credits / Exploit 方式(Hybrid·VFS·SBX)/ Modify Offsets /
Kernelcache 的 Fetch & Remove / Keep Alive / 日志显示方式 / 文件管理器显示模式。

## 为什么 `TaskRop/RemoteCall.m` 还在

exploit 的收尾步骤(把内核读写能力交给 launchd、之后还能找回来)走的是 `persistence.m`,
而 `persistence.m` 内部就是靠 RemoteCall 跟 launchd 通信的;`TaskRop/vm.m`、`thread.m`、`exc.m`
也直接引用它的类型。**把它删掉 exploit 就跑不完整**,所以这一层底层库保留了,
但**用户能碰到的 RemoteCall 功能入口已经一个不剩**(UI、状态、封装方法全部删掉)。

## 构建

**有 Mac(Xcode 16 以上)**

```bash
./build.sh          # Release,产物在 build/lara.ipa
./build.sh --debug  # Debug 版,会显示 Debug Only 那个 kernel_base 段
```

**没有 Mac** — 推到 GitHub 上跑 Actions(仓库自带 `.github/workflows/build.yml`,
macOS runner 上跑同一个 `build.sh`),构建完在 Actions 页面的 Artifacts 里下 `lara-decrypt-ipa`。

产物是**未签名 ipa**,自己签:

- 用自签工具(ESign / Feather / Sideloadly 之类)装,普通用户证书即可
- 或者自己有证书:`codesign -f -s "证书名" --entitlements Config/lara.entitlements Payload/lara.app`

### 签名权限提醒

`Config/lara.entitlements` 里带了一批私有权限(`platform-application`、`no-sandbox`、
`proc_info-allow`、`IOMFB/AGX/IOSurface` 的 iokit 例外等)。这些不是开发者证书能给的东西:

- **在越狱 / 支持 CoreTrust 绕过的环境**(TrollStore 那一类安装器):原样带上,exploit 成功率最高
- **纯普通证书自签**:这些权限会被系统拒掉,安装器可能报错,或者装上后 exploit 起不来
  → 这种环境下建议把 entitlements 精简成只留 `get-task-allow` + 网络 + 文件访问那几项再签,
  漏洞本身走的是用户态可达的 IOSurface / AGX 路径,`IOSurface*` / `AGX*` 那几个 iokit 例外务必保留

> iOS 17.5.1 上没有 TrollStore(它只到 17.0),所以自签这条路能不能跑通,取决于
> 你的签名工具能不能保留 iokit-user-client-class 那几条例外 —— 装上去先看 exploit 有没有跑完。

## 支持范围(沿用上游)

iOS 16.0 – 18.7.1、iOS 26.0.x,排除 M5 与 A19(A19+/M5+ 有 MIE)。
**iPhone 15 / iOS 17.5.1 = A16,在范围内。**

## 改动 app 名字 / 包名

- 名字:`lara.xcodeproj` → target `lara` → General → Display Name(或加 `INFOPLIST_KEY_CFBundleDisplayName`)
- 包名:Build Settings → `PRODUCT_BUNDLE_IDENTIFIER`(默认 `com.roooot.lara`)

## 关于 `OverwriteFiles/`

原版给 SpringBoard 主题功能准备的一堆素材(`.materialrecipe` / `.visualstyleset` / `.car`),
相关功能已经删了,这些文件现在是死资源(约占几百 KB)。想彻底清掉:在 Xcode 里选中
`OverwriteFiles` 组 → Delete → Move to Trash,然后同步删掉磁盘上的目录即可
(工程用的是文件夹同步模式,`lara/` 目录下删文件会自动退出编译,这个组需要手动清)。

## 许可证

上游 lara 是 **AGPL-3.0**,本裁剪版沿用同一许可证,见 `LICENSE`。
内核漏洞实现来自 DarkSword / libgrabkernel2 / XPF 等上游项目,各自的 LICENSE 在 `lara/licenses/` 里。
